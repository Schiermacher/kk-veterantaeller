/* Klassikerkanalen Marked – ruller tælleren op til det rigtige tal.
   Uden JavaScript står det rigtige tal der bare. Der tælles aldrig videre. */
(function () {
  // Plan B: temaet kalder ikke wp_body_open – flyt båndet op øverst.
  var flyt = document.getElementById('kkm-flyt');
  if (flyt && flyt.firstElementChild) {
    document.body.insertBefore(flyt.firstElementChild, document.body.firstChild);
    flyt.remove();
  }
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var baand = document.querySelector('.kkm-baand');
  if (!baand) return;
  var ruller = baand.querySelectorAll('.kkm-rulle');
  ruller.forEach(function (r) { r.style.setProperty('--c', 0); });
  void baand.offsetHeight; // lås startpositionen
  baand.classList.add('kkm-rul');
  setTimeout(function () {
    ruller.forEach(function (r, i) {
      r.style.transitionDelay = (i * 0.08) + 's';
      r.style.setProperty('--c', r.parentNode.getAttribute('data-c'));
    });
  }, 250);
})();
