<?php
/**
 * Plugin Name: Klassikerkanalen Marked
 * Description: Veterantælleren øverst på sitet (Motorregistret) og Klassikerbarometeret (markedstal fra AutoUncle m.fl.).
 * Version: 0.2.0
 * Author: Klassikerkanalen
 * Text Domain: kk-marked
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('KKM_VERSION', '0.2.0');
require_once __DIR__ . '/veteraner.php';
define('KKM_URL', plugin_dir_url(__FILE__));

/* ------------------------------------------------------------------ *
 * Hjælpere
 * ------------------------------------------------------------------ */

function kkm_tal($n, $dec = 0)
{
    return number_format((float) $n, $dec, ',', '.');
}

function kkm_kr($n)
{
    return kkm_tal(round($n)) . ' kr.';
}

function kkm_dato($iso)
{
    $ts = strtotime($iso);
    if (!$ts) {
        return '';
    }
    $mdr = ['januar', 'februar', 'marts', 'april', 'maj', 'juni', 'juli', 'august', 'september', 'oktober', 'november', 'december'];
    return (int) date('j', $ts) . '. ' . $mdr[(int) date('n', $ts) - 1] . ' ' . date('Y', $ts);
}

function kkm_maaned($ym)
{
    $mdr = ['januar', 'februar', 'marts', 'april', 'maj', 'juni', 'juli', 'august', 'september', 'oktober', 'november', 'december'];
    $p = explode('-', $ym);
    return isset($p[1]) ? $mdr[(int) $p[1] - 1] . ' ' . $p[0] : $ym;
}

function kkm_opt($key, $default = '')
{
    $o = get_option('kkm_indstillinger', []);
    return isset($o[$key]) && $o[$key] !== '' ? $o[$key] : $default;
}

function kkm_tabel()
{
    global $wpdb;
    return $wpdb->prefix . 'kk_marked';
}

/* ------------------------------------------------------------------ *
 * Aktivering: tabel + daglig hentning
 * ------------------------------------------------------------------ */

register_activation_hook(__FILE__, function () {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $t = kkm_tabel();
    $c = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE $t (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        maaned char(7) NOT NULL,
        niveau varchar(20) NOT NULL,
        noegle varchar(190) NOT NULL,
        kilde varchar(60) NOT NULL,
        antal int(11) NOT NULL DEFAULT 0,
        median_pris int(11) DEFAULT NULL,
        median_liggetid int(11) DEFAULT NULL,
        andel_prisaendring decimal(5,1) DEFAULT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY raekke (maaned,niveau,noegle,kilde),
        KEY niveau (niveau,maaned)
    ) $c;");
    if (!wp_next_scheduled('kkm_hent_taeller')) {
        wp_schedule_event(time() + 300, 'twicedaily', 'kkm_hent_taeller');
    }
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('kkm_hent_taeller');
});

/* ------------------------------------------------------------------ *
 * Veterantælleren: hent JSON
 * ------------------------------------------------------------------ */

add_action('kkm_hent_taeller', 'kkm_hent_taeller');

function kkm_hent_taeller()
{
    $url = kkm_opt('json_url');
    if (!$url) {
        return new WP_Error('kkm', 'Der er ikke angivet en adresse til tællerens datafil.');
    }
    $svar = wp_remote_get($url, ['timeout' => 20]);
    if (is_wp_error($svar)) {
        return $svar;
    }
    if (wp_remote_retrieve_response_code($svar) !== 200) {
        return new WP_Error('kkm', 'Datafilen svarede med kode ' . wp_remote_retrieve_response_code($svar) . '.');
    }
    $d = json_decode(wp_remote_retrieve_body($svar), true);
    if (!is_array($d) || empty($d['veteranbiler_registreret']) || (int) $d['veteranbiler_registreret'] < 1000) {
        // Et urealistisk lavt tal betyder fejl i optællingen – behold det gamle tal.
        return new WP_Error('kkm', 'Datafilen indeholdt ikke et brugbart tal. Det gamle tal er bevaret.');
    }
    update_option('kkm_taeller', [
        'antal'    => (int) $d['veteranbiler_registreret'],
        'aendring' => isset($d['aendring_siden_sidst']) ? $d['aendring_siden_sidst'] : null,
        'dato'     => isset($d['eksportdato']) ? sanitize_text_field($d['eksportdato']) : '',
        'graense'  => isset($d['graense_aar']) ? (int) $d['graense_aar'] : 35,
        'hentet'   => current_time('mysql'),
        'raa'      => $d,
    ], false);
    return true;
}

/* ------------------------------------------------------------------ *
 * Veterantælleren: visning
 * ------------------------------------------------------------------ */

function kkm_taeller_html()
{
    $t = get_option('kkm_taeller');
    if (!$t || empty($t['antal'])) {
        return '';
    }
    $tal = kkm_tal($t['antal']);
    $cifre = '';
    foreach (str_split($tal) as $c) {
        if (ctype_digit($c)) {
            $cifre .= '<span class="kkm-ciffer" data-c="' . esc_attr($c) . '"><span class="kkm-rulle" style="--c:' . esc_attr($c) . '">'
                . '<span>0</span><span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span><span>7</span><span>8</span><span>9</span></span></span>';
        } else {
            $cifre .= '<span class="kkm-sep">' . esc_html($c) . '</span>';
        }
    }
    $aendring = '';
    if (isset($t['aendring']) && $t['aendring'] !== null && (int) $t['aendring'] !== 0) {
        $a = (int) $t['aendring'];
        $aendring = '<span class="kkm-aendring">' . ($a > 0 ? '+' : '−') . esc_html(kkm_tal(abs($a))) . ' siden sidst</span>';
    }
    $label = kkm_opt('label', 'Veteranbiler på danske plader');
    $side = kkm_opt('side_url');
    $tag_aab = $side ? '<a class="kkm-baand" href="' . esc_url($side) . '"' : '<div class="kkm-baand"';
    $tag_luk = $side ? '</a>' : '</div>';
    $fakta_html = '';
    if (kkm_opt('vis_fakta', '1') === '1') {
        $fakta = kkm_fakta();
        if ($fakta) {
            $start = (int) (time() / 3600) % count($fakta);
            $fakta_html = '<span class="kkm-fakta" aria-live="off" data-fakta="' . esc_attr(wp_json_encode(array_values($fakta))) . '" data-start="' . $start . '">'
                . '<span class="kkm-vd">Vidste du?</span> <span class="kkm-ft">' . esc_html($fakta[$start]) . '</span></span>';
        }
    }

    return $tag_aab . ' role="region" aria-label="' . esc_attr($label . ': ' . $tal) . '">'
        . '<span class="kkm-striber" aria-hidden="true"></span>'
        . '<span class="kkm-indhold">'
        . '<span class="kkm-label">' . esc_html($label) . '</span>'
        . '<span class="kkm-tæller" aria-hidden="true">' . $cifre . '</span>'
        . $aendring
        . '<span class="kkm-kilde">Motorregistret, ' . esc_html(kkm_dato($t['dato'])) . '</span>'
        . '</span>'
        . $fakta_html
        . $tag_luk;
}

$GLOBALS['kkm_vist'] = false;

add_action('wp_body_open', function () {
    if (is_admin() || !kkm_opt('vis_baand', '1') || kkm_opt('vis_baand') === '0') {
        return;
    }
    $h = kkm_taeller_html();
    if ($h) {
        echo $h; // phpcs:ignore -- escaped i kkm_taeller_html
        $GLOBALS['kkm_vist'] = true;
    }
}, 1);

// Plan B: hvis temaet ikke kalder wp_body_open, flyttes båndet op med JavaScript.
add_action('wp_footer', function () {
    if ($GLOBALS['kkm_vist'] || kkm_opt('vis_baand') === '0') {
        return;
    }
    $h = kkm_taeller_html();
    if ($h) {
        echo '<div id="kkm-flyt" hidden>' . $h . '</div>'; // phpcs:ignore
    }
}, 1);

add_shortcode('kk_veterantaeller', function () {
    return kkm_taeller_html();
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('kk-marked', KKM_URL . 'assets/marked.css', [], KKM_VERSION);
    wp_enqueue_script('kk-marked', KKM_URL . 'assets/marked.js', [], KKM_VERSION, true);
});

/* ------------------------------------------------------------------ *
 * Klassikerbarometeret: data
 * ------------------------------------------------------------------ */

function kkm_seneste_maaned($kilde = '')
{
    global $wpdb;
    $t = kkm_tabel();
    if ($kilde) {
        return $wpdb->get_var($wpdb->prepare("SELECT MAX(maaned) FROM $t WHERE kilde = %s", $kilde));
    }
    return $wpdb->get_var("SELECT MAX(maaned) FROM $t");
}

function kkm_raekker($niveau, $maaned, $kilde = '')
{
    global $wpdb;
    $t = kkm_tabel();
    $sql = "SELECT * FROM $t WHERE niveau = %s AND maaned = %s";
    $args = [$niveau, $maaned];
    if ($kilde) {
        $sql .= ' AND kilde = %s';
        $args[] = $kilde;
    }
    $sql .= ' ORDER BY antal DESC';
    return $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
}

function kkm_forrige_maaned($ym)
{
    $ts = strtotime($ym . '-01 -1 month');
    return date('Y-m', $ts);
}

function kkm_kredit($kilde)
{
    if ($kilde === 'AutoUncle') {
        $url = kkm_opt('url_autouncle', 'https://klassikermarkedet.dk/');
        return 'AutoUncle / <a href="' . esc_url($url) . '" rel="noopener">Klassikermarkedet.dk</a>';
    }
    return esc_html($kilde);
}

function kkm_sparkline($noegle, $niveau, $kilde, $maaneder = 12)
{
    global $wpdb;
    $t = kkm_tabel();
    $r = $wpdb->get_results($wpdb->prepare(
        "SELECT maaned, median_pris, antal FROM $t WHERE noegle = %s AND niveau = %s AND kilde = %s ORDER BY maaned DESC LIMIT %d",
        $noegle, $niveau, $kilde, $maaneder
    ), ARRAY_A);
    $min_n = (int) kkm_opt('min_n', 8);
    $r = array_reverse(array_filter($r, function ($x) use ($min_n) {
        return $x['median_pris'] && (int) $x['antal'] >= $min_n;
    }));
    if (count($r) < 3) {
        return '';
    }
    $vals = array_map('intval', array_column($r, 'median_pris'));
    $lo = min($vals);
    $hi = max($vals);
    $span = max(1, $hi - $lo);
    $w = 160;
    $h = 36;
    $pts = [];
    $n = count($vals);
    foreach ($vals as $i => $v) {
        $x = round($i * ($w - 4) / ($n - 1) + 2, 1);
        $y = round($h - 3 - ($v - $lo) * ($h - 6) / $span, 1);
        $pts[] = "$x,$y";
    }
    $sidste = end($pts);
    list($sx, $sy) = explode(',', $sidste);
    return '<svg class="kkm-spark" viewBox="0 0 ' . $w . ' ' . $h . '" width="' . $w . '" height="' . $h . '" role="img" aria-label="'
        . esc_attr('Median-udbudspris de seneste ' . $n . ' måneder, fra ' . kkm_kr($vals[0]) . ' til ' . kkm_kr(end($vals))) . '">'
        . '<polyline fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" points="' . esc_attr(implode(' ', $pts)) . '"/>'
        . '<circle cx="' . esc_attr($sx) . '" cy="' . esc_attr($sy) . '" r="3"/></svg>';
}

/* ------------------------------------------------------------------ *
 * Klassikerbarometeret: shortcodes
 * ------------------------------------------------------------------ */

// [kk_barometer kilde="AutoUncle" antal="15"]
add_shortcode('kk_barometer', function ($atts) {
    $a = shortcode_atts(['kilde' => 'AutoUncle', 'antal' => 15], $atts);
    $kilde = sanitize_text_field($a['kilde']);
    $m = kkm_seneste_maaned($kilde);
    if (!$m) {
        return '<p class="kkm-tom">Klassikerbarometeret opdateres, når de første markedstal er indlæst.</p>';
    }
    $min_n = (int) kkm_opt('min_n', 8);
    $total = kkm_raekker('total', $m, $kilde);
    $forrige = kkm_raekker('total', kkm_forrige_maaned($m), $kilde);
    $t0 = $total ? $total[0] : null;
    $f0 = $forrige ? $forrige[0] : null;

    $ud = '<section class="kkm-barometer">';
    $ud .= '<p class="kkm-maaned">Opgjort for ' . esc_html(kkm_maaned($m)) . '</p>';

    if ($t0) {
        $kort = [
            ['Klassikere til salg', kkm_tal($t0['antal']), $f0 ? (int) $t0['antal'] - (int) $f0['antal'] : null, ''],
            ['Median-udbudspris', $t0['median_pris'] ? kkm_kr($t0['median_pris']) : '–', ($f0 && $f0['median_pris'] && $t0['median_pris']) ? round(((int) $t0['median_pris'] - (int) $f0['median_pris']) / (int) $f0['median_pris'] * 100, 1) : null, ' pct.'],
            ['Median-liggetid', $t0['median_liggetid'] !== null ? kkm_tal($t0['median_liggetid']) . ' dage' : '–', ($f0 && $f0['median_liggetid'] !== null && $t0['median_liggetid'] !== null) ? (int) $t0['median_liggetid'] - (int) $f0['median_liggetid'] : null, ' dage'],
            ['Med prisændring', $t0['andel_prisaendring'] !== null ? kkm_tal($t0['andel_prisaendring'], 1) . ' pct.' : '–', ($f0 && $f0['andel_prisaendring'] !== null && $t0['andel_prisaendring'] !== null) ? round($t0['andel_prisaendring'] - $f0['andel_prisaendring'], 1) : null, ' point'],
        ];
        $ud .= '<div class="kkm-kort">';
        foreach ($kort as $k) {
            $d = '';
            if ($k[2] !== null && $k[2] != 0) {
                $d = '<span class="kkm-delta ' . ($k[2] > 0 ? 'op' : 'ned') . '">' . ($k[2] > 0 ? '▲ +' : '▼ −')
                    . esc_html(kkm_tal(abs($k[2]), is_float($k[2]) ? 1 : 0) . $k[3]) . '</span>';
            }
            $ud .= '<div class="kkm-noegletal"><span class="kkm-n-label">' . esc_html($k[0]) . '</span><span class="kkm-n-tal">' . esc_html($k[1]) . '</span>' . $d . '</div>';
        }
        $ud .= '</div>';
    }

    foreach (['alder' => 'Alder', 'maerke' => 'Mærker', 'aarti' => 'Årtier'] as $niv => $titel) {
        $r = array_filter(kkm_raekker($niv, $m, $kilde), function ($x) use ($min_n) {
            return (int) $x['antal'] >= $min_n;
        });
        if (!$r) {
            continue;
        }
        if ($niv === 'aarti' || $niv === 'alder') {
            usort($r, function ($x, $y) {
                return strcmp($x['noegle'], $y['noegle']);
            });
        } else {
            $r = array_slice($r, 0, (int) $a['antal']);
        }
        $ud .= '<h3 class="kkm-h">' . esc_html($titel) . '</h3><div class="kkm-tabel-wrap"><table class="kkm-tabel"><thead><tr>'
            . '<th scope="col">' . ($niv === 'aarti' ? 'Årti' : ($niv === 'alder' ? 'Alder' : 'Mærke')) . '</th><th scope="col">Til salg</th><th scope="col">Median-udbudspris</th><th scope="col">Liggetid</th><th scope="col">Prisændring</th>'
            . '</tr></thead><tbody>';
        foreach ($r as $x) {
            $ud .= '<tr><th scope="row">' . esc_html($x['noegle']) . '</th>'
                . '<td>' . esc_html(kkm_tal($x['antal'])) . '</td>'
                . '<td>' . ($x['median_pris'] ? esc_html(kkm_kr($x['median_pris'])) : '–') . '</td>'
                . '<td>' . ($x['median_liggetid'] !== null ? esc_html(kkm_tal($x['median_liggetid'])) . ' dage' : '–') . '</td>'
                . '<td>' . ($x['andel_prisaendring'] !== null ? esc_html(kkm_tal($x['andel_prisaendring'], 1)) . ' pct.' : '–') . '</td></tr>';
        }
        $ud .= '</tbody></table></div>';
    }

    $metode = kkm_opt('metode_url');
    $ud .= '<p class="kkm-fod">Tal: ' . kkm_kredit($kilde) . '. Udbudspriser i annoncer, ikke handelspriser. Medianer vises kun, når der er mindst '
        . esc_html($min_n) . ' biler.' . ($metode ? ' <a href="' . esc_url($metode) . '">Sådan regner vi</a>.' : '') . '</p>';
    $ud .= '</section>';
    return $ud;
});

// [kk_marked noegle="Volvo P1800" niveau="model" kilde="AutoUncle"] – boks til købsguider
add_shortcode('kk_marked', function ($atts) {
    $a = shortcode_atts(['noegle' => '', 'niveau' => 'model', 'kilde' => 'AutoUncle', 'titel' => 'Markedet lige nu'], $atts);
    if (!$a['noegle']) {
        return '';
    }
    global $wpdb;
    $t = kkm_tabel();
    $x = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $t WHERE noegle = %s AND niveau = %s AND kilde = %s ORDER BY maaned DESC LIMIT 1",
        $a['noegle'], $a['niveau'], $a['kilde']
    ), ARRAY_A);
    if (!$x) {
        return '';
    }
    $min_n = (int) kkm_opt('min_n', 8);
    $ud = '<aside class="kkm-boks"><p class="kkm-boks-titel">' . esc_html($a['titel']) . ': ' . esc_html($a['noegle']) . '</p>';
    if ((int) $x['antal'] < $min_n) {
        $ud .= '<p>' . esc_html(kkm_tal($x['antal'])) . ' til salg i ' . esc_html(kkm_maaned($x['maaned'])) . '. Det er for få til en sikker medianpris.</p>';
    } else {
        $ud .= '<dl>'
            . '<dt>Til salg</dt><dd>' . esc_html(kkm_tal($x['antal'])) . '</dd>'
            . '<dt>Median-udbudspris</dt><dd>' . ($x['median_pris'] ? esc_html(kkm_kr($x['median_pris'])) : '–') . '</dd>'
            . '<dt>Median-liggetid</dt><dd>' . ($x['median_liggetid'] !== null ? esc_html(kkm_tal($x['median_liggetid'])) . ' dage' : '–') . '</dd>'
            . '</dl>' . kkm_sparkline($a['noegle'], $a['niveau'], $a['kilde']);
    }
    $ud .= '<p class="kkm-fod">' . esc_html(ucfirst(kkm_maaned($x['maaned']))) . '. Tal: ' . kkm_kredit($a['kilde']) . '.</p></aside>';
    return $ud;
});

/* ------------------------------------------------------------------ *
 * Admin
 * ------------------------------------------------------------------ */

add_action('admin_menu', function () {
    add_menu_page('Markedstal', 'Markedstal', 'manage_options', 'kk-marked', 'kkm_admin_side', 'dashicons-chart-line', 58);
});

add_action('admin_init', function () {
    register_setting('kkm', 'kkm_indstillinger', [
        'sanitize_callback' => function ($in) {
            $ud = [];
            foreach (['json_url', 'side_url', 'metode_url', 'url_autouncle'] as $k) {
                $ud[$k] = isset($in[$k]) ? esc_url_raw(trim($in[$k])) : '';
            }
            $ud['label'] = isset($in['label']) ? sanitize_text_field($in['label']) : '';
            $ud['vis_baand'] = !empty($in['vis_baand']) ? '1' : '0';
            $ud['vis_fakta'] = !empty($in['vis_fakta']) ? '1' : '0';
            $ud['min_n'] = isset($in['min_n']) ? max(3, (int) $in['min_n']) : 8;
            return $ud;
        },
    ]);
});

function kkm_admin_side()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    $besked = '';

    if (isset($_POST['kkm_hent_nu']) && check_admin_referer('kkm_hent_nu')) {
        $r = kkm_hent_taeller();
        $besked = is_wp_error($r) ? '<div class="notice notice-error"><p>' . esc_html($r->get_error_message()) . '</p></div>'
            : '<div class="notice notice-success"><p>Tælleren er opdateret.</p></div>';
    }

    if (isset($_POST['kkm_import']) && check_admin_referer('kkm_import')) {
        $besked = kkm_importer_csv();
    }

    $o = get_option('kkm_indstillinger', []);
    $v = function ($k, $d = '') use ($o) {
        return esc_attr(isset($o[$k]) && $o[$k] !== '' ? $o[$k] : $d);
    };
    $t = get_option('kkm_taeller');
    global $wpdb;
    $tab = kkm_tabel();
    $maaneder = $wpdb->get_results("SELECT maaned, kilde, COUNT(*) AS raekker FROM $tab GROUP BY maaned, kilde ORDER BY maaned DESC LIMIT 24", ARRAY_A);
    ?>
    <div class="wrap">
        <h1>Markedstal</h1>
        <?php echo $besked; // phpcs:ignore ?>

        <h2>1. Veterantælleren</h2>
        <p>
            <?php if ($t && !empty($t['antal'])) : ?>
                Seneste tal: <strong><?php echo esc_html(kkm_tal($t['antal'])); ?></strong>
                (Motorregistret, <?php echo esc_html(kkm_dato($t['dato'])); ?>). Hentet <?php echo esc_html($t['hentet']); ?>.
            <?php else : ?>
                Intet tal endnu. Båndet vises først, når der er hentet et tal.
            <?php endif; ?>
        </p>
        <form method="post"><?php wp_nonce_field('kkm_hent_nu'); ?>
            <p><button class="button" name="kkm_hent_nu" value="1">Hent tallet nu</button></p>
        </form>

        <form method="post" action="options.php">
            <?php settings_fields('kkm'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row">Vis båndet øverst</th><td><label><input type="checkbox" name="kkm_indstillinger[vis_baand]" value="1" <?php checked($v('vis_baand', '1'), '1'); ?>> Ja</label></td></tr>
                <tr><th scope="row">Vis "Vidste du?" i båndet</th><td><label><input type="checkbox" name="kkm_indstillinger[vis_fakta]" value="1" <?php checked($v('vis_fakta', '1'), '1'); ?>> Ja</label></td></tr>
                <tr><th scope="row"><label for="kkm-json">Datafil (latest.json)</label></th><td><input id="kkm-json" class="large-text" name="kkm_indstillinger[json_url]" value="<?php echo $v('json_url'); ?>" placeholder="https://raw.githubusercontent.com/BRUGER/kk-veterantaeller/main/data/latest.json"></td></tr>
                <tr><th scope="row"><label for="kkm-label">Tekst i båndet</label></th><td><input id="kkm-label" class="regular-text" name="kkm_indstillinger[label]" value="<?php echo $v('label', 'Veteranbiler på danske plader'); ?>"></td></tr>
                <tr><th scope="row"><label for="kkm-side">Båndet linker til</label></th><td><input id="kkm-side" class="large-text" name="kkm_indstillinger[side_url]" value="<?php echo $v('side_url'); ?>" placeholder="https://klassikerkanalen.dk/veteranbilerne/"></td></tr>
                <tr><th scope="row"><label for="kkm-min">Mindste antal biler for en median</label></th><td><input id="kkm-min" type="number" min="3" name="kkm_indstillinger[min_n]" value="<?php echo $v('min_n', '8'); ?>"></td></tr>
                <tr><th scope="row"><label for="kkm-metode">Side: Sådan regner vi</label></th><td><input id="kkm-metode" class="large-text" name="kkm_indstillinger[metode_url]" value="<?php echo $v('metode_url'); ?>"></td></tr>
                <tr><th scope="row"><label for="kkm-au">Kreditlink AutoUncle</label></th><td><input id="kkm-au" class="large-text" name="kkm_indstillinger[url_autouncle]" value="<?php echo $v('url_autouncle', 'https://klassikermarkedet.dk/'); ?>"></td></tr>
            </table>
            <?php submit_button('Gem indstillinger'); ?>
        </form>

        <h2>2. Indlæs markedstal (CSV)</h2>
        <p>Kolonner: <code>maaned;niveau;noegle;kilde;antal;median_pris;median_liggetid;andel_prisaendring</code><br>
            niveau er <code>total</code>, <code>maerke</code>, <code>aarti</code>, <code>alder</code> eller <code>model</code>. Findes rækken i forvejen, overskrives den.</p>
        <form method="post" enctype="multipart/form-data"><?php wp_nonce_field('kkm_import'); ?>
            <p><input type="file" name="kkm_csv" accept=".csv,text/csv" required> <button class="button button-primary" name="kkm_import" value="1">Indlæs</button></p>
        </form>

        <?php if ($maaneder) : ?>
            <h3>Indlæste måneder</h3>
            <table class="widefat striped" style="max-width:520px"><thead><tr><th>Måned</th><th>Kilde</th><th>Rækker</th></tr></thead><tbody>
            <?php foreach ($maaneder as $m) : ?>
                <tr><td><?php echo esc_html($m['maaned']); ?></td><td><?php echo esc_html($m['kilde']); ?></td><td><?php echo esc_html($m['raekker']); ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
        <?php endif; ?>

        <h2>3. Brug på sitet</h2>
        <p><code>[kk_barometer]</code> på siden Klassikerbarometeret.<br>
            <code>[kk_marked noegle="Volvo P1800"]</code> i en købsguide.<br>
            <code>[kk_veteranbilerne]</code> på siden om veteranbilerne (toplister, årgange, fakta).<br>
            <code>[kk_veterantaeller]</code> hvis tælleren skal stå et andet sted end øverst.</p>
    </div>
    <?php
}

function kkm_tal_ind($s)
{
    $s = trim((string) $s);
    if ($s === '' || $s === '-' || strtolower($s) === 'na') {
        return null;
    }
    $s = str_replace([' ', 'kr.', 'kr', '%'], '', $s);
    if (preg_match('/^-?\d{1,3}(\.\d{3})+(,\d+)?$/', $s)) {
        // dansk med tusindtalspunktum: 152.500 / 12.500,5
        $s = str_replace(['.', ','], ['', '.'], $s);
    } elseif (preg_match('/^-?\d{1,3}(,\d{3})+(\.\d+)?$/', $s)) {
        // engelsk med tusindtalskomma: 152,500
        $s = str_replace(',', '', $s);
    } else {
        // decimalkomma: 21,1
        $s = str_replace(',', '.', $s);
    }
    return is_numeric($s) ? (float) $s : null;
}

function kkm_importer_csv()
{
    if (empty($_FILES['kkm_csv']['tmp_name']) || !is_uploaded_file($_FILES['kkm_csv']['tmp_name'])) {
        return '<div class="notice notice-error"><p>Ingen fil modtaget.</p></div>';
    }
    return kkm_importer_fil($_FILES['kkm_csv']['tmp_name']);
}

function kkm_importer_fil($sti)
{
    $fh = fopen($sti, 'r');
    $foerste = fgets($fh);
    $foerste = preg_replace('/^\xEF\xBB\xBF/', '', $foerste);
    $sep = substr_count($foerste, ';') >= substr_count($foerste, ',') ? ';' : ',';
    $hoved = array_map(function ($h) {
        return strtolower(trim($h));
    }, str_getcsv($foerste, $sep));
    $krav = ['maaned', 'niveau', 'noegle', 'kilde', 'antal'];
    foreach ($krav as $k) {
        if (!in_array($k, $hoved, true)) {
            fclose($fh);
            return '<div class="notice notice-error"><p>Kolonnen «' . esc_html($k) . '» mangler i første linje.</p></div>';
        }
    }
    global $wpdb;
    $t = kkm_tabel();
    $ok = 0;
    $fejl = [];
    $linje = 1;
    while (($r = fgetcsv($fh, 0, $sep)) !== false) {
        $linje++;
        if (count(array_filter($r, 'strlen')) === 0) {
            continue;
        }
        $rad = [];
        foreach ($hoved as $i => $h) {
            $rad[$h] = isset($r[$i]) ? trim($r[$i]) : '';
        }
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $rad['maaned'])
            || !in_array($rad['niveau'], ['total', 'maerke', 'aarti', 'alder', 'model'], true)
            || $rad['noegle'] === '' || $rad['kilde'] === '') {
            $fejl[] = $linje;
            continue;
        }
        $antal = kkm_tal_ind($rad['antal']);
        $pris = isset($rad['median_pris']) ? kkm_tal_ind($rad['median_pris']) : null;
        $ligge = isset($rad['median_liggetid']) ? kkm_tal_ind($rad['median_liggetid']) : null;
        $andel = isset($rad['andel_prisaendring']) ? kkm_tal_ind($rad['andel_prisaendring']) : null;
        $res = $wpdb->replace($t, [
            'maaned' => $rad['maaned'],
            'niveau' => $rad['niveau'],
            'noegle' => mb_substr(sanitize_text_field($rad['noegle']), 0, 190),
            'kilde' => mb_substr(sanitize_text_field($rad['kilde']), 0, 60),
            'antal' => (int) $antal,
            'median_pris' => $pris === null ? null : (int) round($pris),
            'median_liggetid' => $ligge === null ? null : (int) round($ligge),
            'andel_prisaendring' => $andel,
        ]);
        $res ? $ok++ : $fejl[] = $linje;
    }
    fclose($fh);
    $txt = 'Indlæst: ' . $ok . ' rækker.';
    if ($fejl) {
        $txt .= ' Sprunget over (linje): ' . implode(', ', array_slice($fejl, 0, 20)) . (count($fejl) > 20 ? ' …' : '');
    }
    return '<div class="notice ' . ($fejl ? 'notice-warning' : 'notice-success') . '"><p>' . esc_html($txt) . '</p></div>';
}
