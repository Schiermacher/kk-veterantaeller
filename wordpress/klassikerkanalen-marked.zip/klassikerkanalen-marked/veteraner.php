<?php
/**
 * Klassikerkanalen Marked – fakta og veteranside bygget på Motorregistret.
 * Alle tal kommer fra datafilen (latest.json). Der skrives aldrig et tal, som ikke står i den.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Modeller, hvis tal er under afklaring hos Motorstyrelsen, vises ikke.
define('KKM_SKJUL_MODELLER', ['Morris MASCOT']);

function kkm_raa()
{
    $t = get_option('kkm_taeller');
    return ($t && !empty($t['raa']) && is_array($t['raa'])) ? $t['raa'] : null;
}

/** "Ford MUSTANG" -> "Ford Mustang", "Citroën 2 CV" bevares, "Mg B" -> "MG B" */
function kkm_model_navn($s)
{
    $s = trim((string) $s);
    $s = preg_replace_callback('/\b([A-ZÆØÅÄÖÜ]{4,})\b/u', function ($m) {
        return mb_convert_case($m[1], MB_CASE_TITLE, 'UTF-8');
    }, $s);
    $s = preg_replace('/^Mg\b/u', 'MG', $s);
    $s = preg_replace('/^Bmw\b/u', 'BMW', $s);
    return $s;
}

function kkm_ord($n)
{
    $ord = [1 => 'én', 2 => 'to', 3 => 'tre', 4 => 'fire', 5 => 'fem', 6 => 'seks', 7 => 'syv', 8 => 'otte', 9 => 'ni', 10 => 'ti', 11 => 'elleve', 12 => 'tolv'];
    return isset($ord[$n]) ? $ord[$n] : kkm_tal($n);
}

/** Korte, sande sætninger bygget af datafilen. Ingen sætning begynder med et tal. */
function kkm_fakta($d = null)
{
    $d = $d ?: kkm_raa();
    if (!$d) {
        return [];
    }
    $f = [];
    $aar = [];
    foreach ((array) ($d['pr_aargang'] ?? []) as $k => $v) {
        $aar[(int) $k] = (int) $v;
    }
    ksort($aar);

    if ($aar) {
        $foerste = array_key_first($aar);
        $f[] = 'Den ældste årgang i registret er ' . $foerste . '.';
        $foer1910 = 0;
        foreach ($aar as $y => $n) {
            if ($y < 1910) {
                $foer1910 += $n;
            }
        }
        if ($foer1910 > 0) {
            $f[] = 'Kun ' . kkm_tal($foer1910) . ' indregistrerede biler er fra før 1910.';
        }
        $top = $aar;
        arsort($top);
        $topaar = array_key_first($top);
        $f[] = 'Den største årgang er ' . $topaar . ' med ' . kkm_tal($top[$topaar]) . ' biler.';
        if (isset($aar[1939])) {
            $krig = array_intersect_key($aar, array_flip(range(1940, 1945)));
            if ($krig) {
                $minaar = array_keys($krig, min($krig))[0];
                $f[] = 'Krigen kan ses i registret: ' . kkm_tal($aar[1939]) . ' biler er fra 1939, men kun ' . kkm_tal($krig[$minaar]) . ' fra ' . $minaar . '.';
            }
        }
    }

    if (!empty($d['top_modeller'][0])) {
        list($m, $n) = $d['top_modeller'][0];
        $f[] = 'Danmarks mest almindelige veteranbil er ' . kkm_model_navn($m) . ' med ' . kkm_tal($n) . ' biler.';
    }

    $brug = ['Rustvognskørsel' => 'som rustvogn', 'Ambulancekørsel' => 'som ambulance', 'Taxikørsel' => 'som taxi', 'Limousinekørsel' => 'som limousine', 'Beboelse' => 'til beboelse'];
    foreach ($brug as $k => $tekst) {
        if (!empty($d['anvendelse'][$k])) {
            $f[] = 'Der er ' . kkm_tal($d['anvendelse'][$k]) . ' veteranbiler registreret ' . $tekst . '.';
        }
    }

    $saerlige = ['Ferrari', 'Lamborghini', 'Rolls-Royce', 'Bentley', 'Aston Martin', 'Maserati', 'Trabant', 'Lotus', 'De Tomaso', 'Bugatti'];
    foreach ($saerlige as $mk) {
        foreach ((array) ($d['alle_maerker'] ?? []) as $navn => $n) {
            if (mb_strtolower($navn) === mb_strtolower($mk) && $n > 0) {
                $f[] = 'Der er ' . kkm_tal($n) . ' ' . $mk . (($n == 1) ? '' : '-biler') . ' på danske plader, der er mindst ' . (int) ($d['graense_aar'] ?? 35) . ' år gamle.';
            }
        }
    }

    if (!empty($d['drivkraft']['El'])) {
        $f[] = 'Der er ' . kkm_tal($d['drivkraft']['El']) . ' veteranbiler, der er registreret til at køre på el.';
    }
    if (!empty($d['farver'])) {
        $farver = array_diff_key((array) $d['farver'], ['Ukendt' => 1, 'Ikke oplyst' => 1]);
        $sum = array_sum((array) $d['farver']);
        if ($farver && $sum) {
            arsort($farver);
            $fv = array_key_first($farver);
            $f[] = 'Den mest almindelige farve på en veteranbil er ' . mb_strtolower($fv) . ': ' . kkm_tal($farver[$fv] / $sum * 100, 1) . ' pct.';
        }
    }

    $arter = (array) ($d['alle_koeretoejsarter_registreret'] ?? []);
    if (!empty($arter['Motorcykel'])) {
        $f[] = 'Ud over bilerne er der ' . kkm_tal($arter['Motorcykel']) . ' motorcykler på mindst ' . (int) ($d['graense_aar'] ?? 35) . ' år.';
    }
    if (!empty($arter['Traktor'])) {
        $f[] = 'Der er ' . kkm_tal($arter['Traktor']) . ' traktorer på mindst ' . (int) ($d['graense_aar'] ?? 35) . ' år på danske plader.';
    }

    $md = (int) date('n');
    if (!empty($d['bliver_veteran_1_januar']) && ($md >= 10)) {
        $f[] = 'Den 1. januar kommer ' . kkm_tal($d['bliver_veteran_1_januar']) . ' biler fra ' . ((int) ($d['aargang_til_og_med'] ?? 0) + 1) . ' med i tælleren.';
    }
    return $f;
}

/* ------------------------------------------------------------------ *
 * Veteransiden: [kk_veteranbilerne]
 * ------------------------------------------------------------------ */

function kkm_aargang_svg($aar, $fra, $til)
{
    $max = max($aar) ?: 1;
    $n = $til - $fra + 1;
    $w = 760;
    $h = 220;
    $pl = 44;
    $pb = 26;
    $pt = 10;
    $bw = ($w - $pl - 8) / $n;
    $ud = '<svg class="kkm-aargang" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-labelledby="kkm-ag-t">';
    $ud .= '<title id="kkm-ag-t">Antal indregistrerede veteranbiler pr. årgang, ' . $fra . '–' . $til . '. Flest fra ' . array_search($max, $aar) . ' med ' . kkm_tal($max) . '.</title>';
    // gitterlinjer
    $trin = $max > 2000 ? 1000 : ($max > 600 ? 500 : 100);
    for ($g = 0; $g <= $max; $g += $trin) {
        $y = $h - $pb - ($g / $max) * ($h - $pb - $pt);
        $ud .= '<line x1="' . $pl . '" x2="' . ($w - 4) . '" y1="' . round($y, 1) . '" y2="' . round($y, 1) . '" class="kkm-g"/>';
        $ud .= '<text x="' . ($pl - 6) . '" y="' . round($y + 4, 1) . '" text-anchor="end" class="kkm-ax">' . kkm_tal($g) . '</text>';
    }
    if ($fra <= 1940 && $til >= 1945) {
        $ud .= '<rect class="kkm-krigbg" x="' . round($pl + (1940 - $fra) * $bw, 1) . '" y="' . $pt . '" width="' . round(6 * $bw, 1) . '" height="' . ($h - $pb - $pt) . '"/>';
    }
    for ($y = $fra; $y <= $til; $y++) {
        $v = $aar[$y] ?? 0;
        $bh = ($v / $max) * ($h - $pb - $pt);
        $x = $pl + ($y - $fra) * $bw;
        $kl = ($y >= 1940 && $y <= 1945) ? 'kkm-b kkm-krig' : 'kkm-b';
        $ud .= '<rect class="' . $kl . '" x="' . round($x + 0.5, 1) . '" y="' . round($h - $pb - $bh, 1) . '" width="' . round(max(1, $bw - 1), 1) . '" height="' . round($bh, 1) . '"><title>' . $y . ': ' . kkm_tal($v) . '</title></rect>';
        if ($y % 10 === 0) {
            $ud .= '<text x="' . round($x + $bw / 2, 1) . '" y="' . ($h - 8) . '" text-anchor="middle" class="kkm-ax">' . $y . '</text>';
        }
    }
    if (isset($aar[1939])) {
        $x = $pl + (1942.5 - $fra) * $bw;
        $y = $h - $pb - (($aar[1939] ?? 0) / $max) * ($h - $pb - $pt) - 14;
        $ud .= '<text x="' . round($x, 1) . '" y="' . round(max(14, $y), 1) . '" text-anchor="middle" class="kkm-ann">Krigsårene</text>';
    }
    return $ud . '</svg>';
}

add_shortcode('kk_veteranbilerne', function () {
    $t = get_option('kkm_taeller');
    $d = kkm_raa();
    if (!$d) {
        return '<p class="kkm-tom">Tallene fra Motorregistret er ikke hentet endnu.</p>';
    }
    $g = (int) ($d['graense_aar'] ?? 35);
    $ud = '<section class="kkm-vet">';
    $ud .= '<p class="kkm-vet-lead"><strong>' . kkm_tal($t['antal']) . '</strong> personbiler, der er mindst ' . $g . ' år gamle, er indregistreret i Danmark. Det viser Motorstyrelsens udtræk af Motorregistret fra '
        . esc_html(kkm_dato($t['dato'])) . '. Tallet omfatter biler, der blev indregistreret første gang i ' . (int) ($d['aargang_til_og_med'] ?? 0) . ' eller tidligere.</p>';

    $aar = [];
    foreach ((array) ($d['pr_aargang'] ?? []) as $k => $v) {
        $aar[(int) $k] = (int) $v;
    }
    ksort($aar);
    if ($aar) {
        $ud .= '<h2>Årgang for årgang</h2>' . kkm_aargang_svg($aar, max(1900, array_key_first($aar)), array_key_last($aar));
        $ud .= '<p class="kkm-fod">Antal indregistrerede personbiler pr. årgang efter første indregistrering. Årgangene 1940–45 er markeret.</p>';
    }

    $tabel = function ($titel, $raekker, $kol, $navnfn) {
        if (!$raekker) {
            return '';
        }
        $h = '<h2>' . esc_html($titel) . '</h2><div class="kkm-tabel-wrap"><table class="kkm-tabel"><thead><tr><th scope="col">#</th><th scope="col">' . esc_html($kol) . '</th><th scope="col">Antal</th></tr></thead><tbody>';
        $i = 0;
        foreach ($raekker as $r) {
            $i++;
            $h .= '<tr><td>' . $i . '</td><th scope="row">' . esc_html($navnfn($r[0])) . '</th><td>' . esc_html(kkm_tal($r[1])) . '</td></tr>';
        }
        return $h . '</tbody></table></div>';
    };
    $modeller = array_values(array_filter((array) ($d['top_modeller'] ?? []), function ($r) {
        return !preg_match('/\s-$/', $r[0]) && !in_array($r[0], KKM_SKJUL_MODELLER, true);
    }));
    $ud .= $tabel('De mest almindelige modeller', array_slice($modeller, 0, 15), 'Model', 'kkm_model_navn');
    $ud .= $tabel('De mest almindelige mærker', array_slice((array) ($d['top_maerker'] ?? []), 0, 15), 'Mærke', 'kkm_model_navn');

    if (!empty($d['aeldste'])) {
        $ud .= '<h2>De ældste</h2><div class="kkm-tabel-wrap"><table class="kkm-tabel"><thead><tr><th scope="col">Første indregistrering</th><th scope="col">Bil</th></tr></thead><tbody>';
        foreach (array_slice($d['aeldste'], 0, 10) as $r) {
            $ud .= '<tr><td>' . esc_html(kkm_dato($r['dato']) ?: $r['dato']) . '</td><th scope="row">' . esc_html(kkm_model_navn(trim($r['maerke'] . ' ' . $r['model']))) . '</th></tr>';
        }
        $ud .= '</tbody></table></div>';
    }

    $fakta = kkm_fakta($d);
    if ($fakta) {
        $ud .= '<h2>Vidste du?</h2><ul class="kkm-fakta-liste">';
        foreach ($fakta as $s) {
            $ud .= '<li>' . esc_html($s) . '</li>';
        }
        $ud .= '</ul>';
    }

    $metode = kkm_opt('metode_url');
    $ud .= '<p class="kkm-fod">Kilde: Motorregistret (DMR), Motorstyrelsens ugentlige udtræk. Klassikerkanalen tæller personbiler med status "Registreret", hvor første indregistrering ligger mindst '
        . $g . ' år tilbage. Opdateres to gange om ugen.' . ($metode ? ' <a href="' . esc_url($metode) . '">Sådan regner vi</a>.' : '') . '</p>';
    return $ud . '</section>';
});
